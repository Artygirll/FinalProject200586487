// firebaseConfig.txs
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
    apiKey: "AIzaSyBoFPjeCrL8s4rZx_p6nhYzNWO6TdRPkCQ",
     authDomain: "checkits-b17ec.firebaseapp.com",
     projectId: "checkits-b17ec",
     storageBucket: "checkits-b17ec.firebasestorage.app",
     messagingSenderId: "398106396750",
     appId: "1:398106396750:web:d0d6cb8756ce63b6d39b1f",
     measurementId: "G-V6H8Q09XT8"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { app, auth, db };
