import {
  Image,
  StyleSheet,
  Platform,
  ScrollView,
  View,
  Text,
  TouchableOpacity,
  Button,
} from 'react-native';
import React, { useState } from 'react';
import { HelloWave } from '@/components/BounceEffect';
import { Achieved, Warning } from '@/components/ScaleEffect';
import ParallaxScrollView from '@/components/ParallaxScrollView';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { AnimatedCircularProgress } from '@/node_modules/react-native-circular-progress';
import { useLocalSearchParams } from 'expo-router';
import Carousel from '@/node_modules/react-native-snap-carousel';
import { ProgressBar } from '@/node_modules/react-native-paper';

export default function HomeScreen() {
  const { WorkHours, PersonalHours, _tasks } = useLocalSearchParams();

  console.log('Hello' + _tasks);
  let tasks = [];

  try {
    if (_tasks) {
      tasks = JSON.parse(_tasks);
      console.log(tasks);
    }
  } catch (error) {
    console.error('Error parsing JSON: ', error);
  }

  console.log(Number({ WorkHours }.WorkHours));
  // Convert to numbers, ensuring to handle the undefined case
  const work = WorkHours ? Number({ WorkHours }.WorkHours) : 5; // Default to 5 if not provided
  const personal = PersonalHours ? Number({ PersonalHours }.PersonalHours) : 10; // Default to 10 if not provided

  const totalHours = work + personal;
  const workPercentage = (work / totalHours) * 100;

  // Determine work-life balance status
  const balanceMessage = workPercentage <= 35 ? 'Achieved!' : 'Imbalance!';

  const warningSign = workPercentage > 35 ? <Warning /> : <Achieved />;

  const data = [
    {
      key: 1,
      value: work,
      svg: { fill: '#FF6347' },
      arc: { outerRadius: '90%', cornerRadius: 10 },
    },
    {
      key: 2,
      value: personal,
      svg: { fill: '#87CEEB' },
      arc: { outerRadius: '100%', cornerRadius: 10 },
    },
  ];
  const Legend = () => (
    <View style={styles.legendContainer}>
      <View style={styles.legendItem}>
        <View style={[styles.colorBox, { backgroundColor: '#FF6347' }]} />
        <Text style={styles.legendText}>
          Work:{Math.round(workPercentage)}%
        </Text>
      </View>
      <View style={styles.legendItem}>
        <View style={[styles.colorBox, { backgroundColor: '#87CEEB' }]} />
        <Text style={styles.legendText}>
          Personal:{100 - Math.round(workPercentage)}%
        </Text>
      </View>
    </View>
  );
    const items = [
    {
    title: 'Work-Life Balance Status',
    content: (
    <View style={styles.contentContainer}>
    <AnimatedCircularProgress size={150} width={25} fill={workPercentage} tintColor="#FF6347" tintColorSecondary="#FFA07A" backgroundColor="#87CEEB" duration={1600} lineCap="round" arcSweepAngle={270} rotation={225}>
              {() => <Text style={styles.text}>{balanceMessage}{warningSign}</Text>}
    </AnimatedCircularProgress>
    <Legend />
    </View>
    ),
    },
    {
    title: 'Work Efficiency',
    content: <ProgressBar progress={0.57} color="#6200ee" />,
    },
    // Add more slides as needed
    ];
    const renderItem = ({ item }) => (
    <View style={styles.slide}>
    <Text style={styles.title}>{item.title}</Text>
    {item.content}
    </View>
    );
  const [currentIndex, setCurrentIndex] = useState(0); // Manage the current index of slides

  const handleNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % items.length); // Loop to the start
  };

  const handlePrev = () => {
    setCurrentIndex(
      (prevIndex) => (prevIndex - 1 + items.length) % items.length
    ); // Loop to the end
  };

  return (
    <ParallaxScrollView
      headerBackgroundColor={{ light: '#A1CEDC', dark: '#1D3D47' }}>
      <ThemedView style={styles.titleContainer}>
        <ThemedText type="title">Welcome!</ThemedText>

        <HelloWave />
      </ThemedView>
          <Carousel
          data={items}
          renderItem={renderItem}
          sliderWidth={300}
          itemWidth={300}
          layout={'default'}
          loop={true}
          autoplay={true}
          autoplayDelay={1000}
          autoplayInterval={3000}
          />
      <View style={styles.panel}>
        {/* Upcoming Events Panel */}
        <Text style={styles.sectionTitle}>Upcoming Events</Text>
        <ScrollView style={styles.scrollView}>
          {tasks.map((task) => (
            <View key={task.date} style={styles.taskContainer}>
              <Text style={styles.taskTitle}>{task.title}</Text>
              <Text style={styles.taskTime}>{task.time}</Text>
            </View>
          ))}
        </ScrollView>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View style={styles.container}>
          <Image
            source={require('@/assets/images/1.png')}
            style={styles.image2}
          />
          <Image
            source={require('@/assets/images/2.png')}
            style={styles.image2}
          />
          <Image
            source={require('@/assets/images/3.png')}
            style={styles.image2}
          />
          <Image
            source={require('@/assets/images/4.png')}
            style={styles.image2}
          />
          <Image
            source={require('@/assets/images/5.png')}
            style={styles.image2}
          />
        </View>
      </ScrollView>

      <View>
        <View style={styles.row}>
          {/* First Row of Feed Panels */}
          <View style={styles.feedPanel}>
            <Image
              source={require('@/assets/images/2.png')}
              style={styles.feedImage}
            />
            <Text style={styles.feedText}>Benefits of Merican Clock</Text>
          </View>

          <View style={styles.feedPanel}>
            <Image
              source={require('@/assets/images/3.png')}
              style={styles.feedImage}
            />
            <Text style={styles.feedText}>Professional Care</Text>
          </View>
        </View>

        <View style={styles.row}>
          {/* Second Row of Feed Panels */}
          <View style={styles.feedPanel}>
            <Image
              source={require('@/assets/images/4.png')}
              style={styles.feedImage}
            />
            <Text style={styles.feedText}>Ten Exercises for better health</Text>
          </View>

          <View style={styles.feedPanel}>
            <Image
              source={require('@/assets/images/5.png')}
              style={styles.feedImage}
            />
            <Text style={styles.feedText}>
              Text for the fourth feed item goes here
            </Text>
          </View>
        </View>
      </View>
    </ParallaxScrollView>
  );
}

const styles = StyleSheet.create({
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  container: {
    flexDirection: 'row',
    justifyContent: 'center', // Center the container items
  },
  image2: {
    width: 80, // Increased size for better visibility
    height: 80, // Increased size for better visibility
    marginHorizontal: 10,
    borderRadius: 10,
  },
  // Upcoming Event
  panel: {
    borderRadius: 10,
    backgroundColor: '#87CEEB',
    padding: 10,
    margin: 0,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: 'white',
  },
  scrollView: {
    height: 130,
  },
  taskContainer: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: 'white',
  },
  taskTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  taskTime: {
    fontSize: 14,
    color: 'white',
    marginTop: 5,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 10,
    marginTop: 20,
  },
  feedPanel: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    marginBottom: 10,
    width: '48%',
    alignItems: 'center', // Center content within feed panel
  },
  feedImage: {
    width: '100%',
    height: 150,
    borderTopRightRadius: 10,
    borderTopLeftRadius: 10,
  },
  feedText: {
    padding: 10,
    fontSize: 16,
    textAlign: 'left',
  },
  slide: {
    backgroundColor: 'white', // Background of the slide
    borderRadius: 8,
    height: 250,
    padding: 20,
    justifyContent: 'center',
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'black', // Ensure text is visible
  },
  contentContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontSize: 16,
    color: '#000', // Ensure the text inside the components is also visible
  },
  legendContainer: {
    flexDirection: 'row',
    marginTop: 10,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 10,
  },
  colorBox: {
    width: 20,
    height: 20,
    borderRadius: 5,
    marginRight: 5,
  },
  legendText: {
    fontSize: 14,
    color: '#000',
  },
  chartContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  Chartslide: {
    width: 300, // Set width for the slide
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  Charttitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
      contentContainer: {
        alignItems: 'center',
      },
      Charttext: {
        textAlign: 'center',
      },
      navigation: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '100%',
      },
});
