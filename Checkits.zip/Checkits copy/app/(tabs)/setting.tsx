import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Image,
  View,
  TextInput,
  Switch,
  Button,
  Alert,
  Modal,
  TouchableOpacity,
  Text,
} from 'react-native';
import { Collapsible } from '@/components/Collapsible';
import { ExternalLink } from '@/components/ExternalLink';
import ParallaxScrollView from '@/components/ParallaxScrollView';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { getFirestore, doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db } from './firebaseConfig'; // Import auth from firebaseConfig
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
} from 'firebase/auth';
import { useNavigation, useRouter, useLocalSearchParams } from 'expo-router';

export default function SettingScreen() {
  const [name, setName] = useState('Taylor Swift');
  const [email, setEmail] = useState('taylor@example.com');
  const [password, setPassword] = useState('');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  let user = [];
  let user_id = [];
  const handleSaveChanges = () => {
    Alert.alert(
      'Profile Updated',
      'Your changes have been saved successfully!'
    );
  };
  //
  const handleLogin = async () => {
    try {
      const userCredential = await signInWithEmailAndPassword(
        auth,
        email,
        password
      );
      user = userCredential.user;

      // Fetch user info from Firestore using the UID
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      if (userDoc.exists()) {
        user_id = user.uid;
        const userData = userDoc.data();
        setName(userData.name);
        setEmail(userData.email); // Assuming email is not editable
      } else {
        console.log(user.uid);
        Alert.alert('No user data found');
      }

      Alert.alert('Login Successful');
      setModalVisible(false);
    } catch (error) {
      Alert.alert('Login Failed', error.code + ': ' + error.message);
    }
    const router = useRouter();
    useEffect(() => {
      console.log(user.uid);
      router.push({
        pathname: '/task',
        params: {
          user_id: user_id,
        },
      });

      router.push({ pathname: '/setting' });
    }, []);
  };

  const handleSignUp = async () => {
    try {
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        email,
        password
      );
      user = userCredential.user; // This contains the user's UID

      // Save user info to Firestore using the UID as the document ID
      await setDoc(doc(db, 'users', user.uid), {
        name: name,
        email: user.email,
        profilePicture: '', // Optional: URL for profile picture
      });

      Alert.alert('Registration Successful');
      setModalVisible(false);
    } catch (error) {
      Alert.alert('Registration Failed', error.code + ': ' + error.message);
    }
  };

  return (
    <ParallaxScrollView
      headerBackgroundColor={{ light: '#F5F5F5', dark: '#1E1E1E' }}>
      {/* Profile Section */}
      <ThemedView style={styles.profileContainer}>
        <Image
          source={require('@/assets/images/images.jpeg')}
          style={styles.profileImage}
        />
        <TextInput
          style={styles.input}
          value={name}
          onChangeText={setName}
          placeholder="Enter your name"
        />
        <TextInput
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          placeholder="Enter your email"
          keyboardType="email-address"
        />
        <Button title="Save Changes" onPress={handleSaveChanges} />
        {/* Login Button */}
        <TouchableOpacity
          style={styles.loginButton}
          onPress={() => setModalVisible(true)}>
          <Text style={styles.loginButtonText}>Login or Sign Up</Text>
        </TouchableOpacity>
      </ThemedView>

      <View style={styles.sectionContainer}>
        {/* Account Information */}
        <Collapsible title="Account Settings">
          <TextInput
            style={styles.input}
            placeholder="Change Password"
            secureTextEntry
          />
          <Button
            title="Update Password"
            onPress={() =>
              Alert.alert(
                'Password Updated',
                'Your password has been changed successfully!'
              )
            }
          />
        </Collapsible>

        {/* Notifications Settings */}
        <Collapsible title="Notification Settings">
          <View style={styles.row}>
            <ThemedText>Enable Notifications</ThemedText>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
            />
          </View>
        </Collapsible>

        {/* Privacy Settings */}
        <Collapsible title="Privacy">
          <View style={styles.row}>
            <ThemedText>Make Profile Private</ThemedText>
            <Switch />
          </View>
        </Collapsible>

        {/* Appearance Settings */}
        <Collapsible title="Appearance">
          <View style={styles.row}>
            <ThemedText>Dark Mode</ThemedText>
            <Switch value={darkMode} onValueChange={setDarkMode} />
          </View>
        </Collapsible>

        {/* Help & Support */}
        <Collapsible title="Help & Support">
          <ThemedText>Need help? Contact our support team.</ThemedText>
          <ExternalLink href="https://example.com/help">
            <ThemedText type="link">Go to Support</ThemedText>
          </ExternalLink>
        </Collapsible>

        {/* Logout Button */}
        <Button
          title="Log Out"
          color="red"
          onPress={() =>
            Alert.alert('Logged Out', 'You have been logged out successfully!')
          }
        />
      </View>

      {/* Modal for Login/Signup */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalView}>
          <Text style={styles.title}>{isSignUp ? 'Sign Up' : 'Login'}</Text>
          <TextInput
            style={styles.input}
            placeholder="Email"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
          />
          <TextInput
            style={styles.input}
            placeholder="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
          <TouchableOpacity
            style={styles.button}
            onPress={isSignUp ? handleSignUp : handleLogin}>
            <Text style={styles.buttonText}>
              {isSignUp ? 'Sign Up' : 'Login'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setIsSignUp(!isSignUp)}>
            <Text style={styles.toggleText}>
              {isSignUp
                ? 'Already have an account? Login'
                : 'Create an account'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => setModalVisible(false)}>
            <Text style={styles.closeButtonText}>Close</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </ParallaxScrollView>
  );
}

const styles = StyleSheet.create({
  profileContainer: {
    alignItems: 'center',
    paddingVertical: 20,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  profileImage: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 10,
    borderWidth: 2,
    borderColor: '#D0D0D0',
  },
  input: {
    width: '80%',
    padding: 10,
    marginVertical: 5,
    borderWidth: 1,
    borderColor: '#D0D0D0',
    borderRadius: 10,
    backgroundColor: '#FAFAFA',
  },
  sectionContainer: {
    paddingHorizontal: 20,
    paddingTop: 10,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
  },
  loginButton: {
    backgroundColor: '#007BFF',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginVertical: 10,
    elevation: 2, // Add shadow for Android
  },
  loginButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
  modalView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 24,
    textAlign: 'center',
    color: '#FFFFFF',
  },
  button: {
    backgroundColor: '#007BFF',
    paddingVertical: 15,
    borderRadius: 5,
    alignItems: 'center',
    width: '80%',
    marginBottom: 16,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  toggleText: {
    color: '#007BFF',
    marginTop: 16,
    textAlign: 'center',
    fontSize: 14,
  },
  closeButton: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#FF4C4C',
    borderRadius: 5,
  },
  closeButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
});
