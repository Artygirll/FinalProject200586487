import {StyleSheet, Image, Platform, View, TouchableOpacity,Modal,Button,TextInput,Text,ScrollView,Dimensions,TouchableWithoutFeedback,Keyboard,ActivityIndicator} from 'react-native';
import { useState, useEffect, useRef } from 'react';
import { Collapsible } from '@/components/Collapsible';
import { ExternalLink } from '@/components/ExternalLink';
import ParallaxScrollView from '@/components/ParallaxScrollView';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { IconSymbol } from '@/components/ui/IconSymbol';
import * as Device from '@/node_modules/expo-device';
import * as Notifications from '@/node_modules/expo-notifications';
import DateTimePicker from '@/node_modules/@react-native-community/datetimepicker';
import DateTimePickerAndroid from '@/node_modules/@react-native-community/datetimepicker';
import Constants from '@/node_modules/expo-constants';
import {useNavigation, useRouter ,useLocalSearchParams} from 'expo-router';
import { TabView, SceneMap, TabBar } from '@/node_modules/react-native-tab-view';
import Svg, { Circle, Line, Text as SvgText } from 'react-native-svg';
import { FontAwesome5 } from '@/node_modules/@expo/vector-icons';
import * as Speech from '@/node_modules/expo-speech';
import brain from '@/node_modules/brain.js';

const activitiesAM = [
  { icon: "bed", label: "Deep Sleep", time: 0, color: "#B0BEC5" }, // 12 AM - 2 AM (Grey)
  { icon: "bed", label: "Deep Sleep", time: 2, color: "#B0BEC5" }, // 2 AM - 4 AM (Grey)
  { icon: "bed", label: "Deep Sleep", time: 4, color: "#B0BEC5" }, // 4 AM - 6 AM (Grey)
  { icon: "coffee", label: "Breakfast", time: 6, color: "#FFA726" }, // 6 AM - 8 AM (Orange)
  { icon: "apple-alt", label: "Digestion", time: 8, color: "#4CAF50" }, // 8 AM - 10 AM (Green)
  { icon: "laptop", label: "Work Mode", time: 10, color: "#3F51B5" }, // 10 AM - 12 PM (Blue)
];

const activitiesPM = [
  { icon: "utensils", label: "Lunch", time: 12, color: "#FF9800" }, // 12 PM - 2 PM (Orange)
  { icon: "laptop", label: "Study", time: 14, color: "#5D4037" }, // 2 PM - 4 PM (Brown)
  { icon: "brain", label: "Creative Work", time: 16, color: "#D50032" }, // 4 PM - 6 PM (Red)
  { icon: "utensils", label: "Dinner", time: 18, color: "#FF9800" }, // 8 PM - 10 PM (Green)
  { icon: "running", label: "Exercise", time: 20, color: "#8BC34A" }, // 6 PM - 8 PM (Yellow)
  { icon: "bed", label: "Relax & Unwind", time: 22, color: "#B0BEC5" }, // 10 PM - 12 AM (Purple)
];


const DatePickerComponent = Platform.OS === 'ios' ? DateTimePicker : DateTimePickerAndroid;
Notifications.setNotificationHandler({
    handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: true,
    }),
    
});
async function sendPushNotification(expoPushToken: string) {
    const message = {
        to: expoPushToken,
        sound: 'default',
        title: 'Wellness Reminder',
        body: 'And here is the body!',
        data: { someData: 'goes here' },
    };
    
    await fetch('https://exp.host/--/api/v2/push/send', {
        method: 'POST',
        headers: {
            Accept: 'application/json',
            'Accept-encoding': 'gzip, deflate',
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(message),
    });
}

function handleRegistrationError(errorMessage: string) {
    alert(errorMessage);
    throw new Error(errorMessage);
}

function formatDate(date) {
    const formattedDate = date instanceof Date ? date : new Date(date);
    const year = formattedDate.getFullYear();
    const month = String(formattedDate.getMonth() + 1).padStart(2, '0');
    const day = String(formattedDate.getDate()).padStart(2, '0');
    const hours = String(formattedDate.getHours()).padStart(2, '0');
    const minutes = String(formattedDate.getMinutes()).padStart(2, '0');
    
    return `${year}/${month}/${day} ${hours}:${minutes}`;
}

async function registerForPushNotificationsAsync() {
    if (Platform.OS === 'android') {
        Notifications.setNotificationChannelAsync('default', {
            name: 'default',
            importance: Notifications.AndroidImportance.MAX,
            vibrationPattern: [0, 250, 250, 250],
            lightColor: '#FF231F7C',
        });
    }
    
    if (Device.isDevice) {
        const { status: existingStatus } = await Notifications.getPermissionsAsync();
        let finalStatus = existingStatus;
        if (existingStatus !== 'granted') {
            const { status } = await Notifications.requestPermissionsAsync();
            finalStatus = status;
        }
        if (finalStatus !== 'granted') {
            handleRegistrationError('Permission not granted to get push token for push notification!');
            return;
        }
        const projectId =
        Constants?.expoConfig?.extra?.eas?.projectId ?? Constants?.easConfig?.projectId;
        if (!projectId) {
            handleRegistrationError('Project ID not found');
        }
        try {
            const pushTokenString = (
                                     await Notifications.getExpoPushTokenAsync({
                                         projectId,
                                     })
                                     ).data;
            console.log(pushTokenString);
            return pushTokenString;
        } catch (e: unknown) {
            handleRegistrationError(`${e}`);
        }
    } else {
        handleRegistrationError('Must use physical device for push notifications');
    }
}

export default function TaskScreen() {
    const { user_id } = useLocalSearchParams();
    const [index, setIndex] = useState(0);
    const [routes] = useState([
        { key: 'tasks', title: 'Work Tasks' },
        { key: 'personalTasks', title: 'Personal Tasks' },
        { key: 'healthTasks', title: 'Health Reminders' },
        
    ]);
    useEffect(() => {
        let user_ids = {user_id} ;
        console.log('UserId:'+user_ids);
    },[]);
    const [expoPushToken, setExpoPushToken] = useState('');
    const [notification, setNotification] = useState();
    const notificationListener = useRef();
    const responseListener = useRef();
    
    const [tasks, setTasks] = useState([
        { id: 1, text: 'Meeting', description: 'Description 1', completed: false, startTime: new Date('2025-01-22T16:30:00.000Z'), deadline: new Date('2025-01-23T17:00:00.000Z'), duration: 5, category: 'work', priority: 'medium',status:'done' },
        { id: 2, text: 'Family Reunion', description: 'Family Time', completed: false, startTime: new Date('2025-01-23T15:00:00.000Z'), deadline: new Date('2025-01-23T16:00:00.000Z'), duration: 10, category: 'personal', priority: 'medium',status:'done' },
    ]);
    const [healthTasks, setHealthTasks] = useState([
        {
            id: 1,
            text: 'Large Intestine (05:00-07:00) - Wake up, hydrate, detoxify, stretch/Exercises',
            description: 'Wake up, hydrate your body with water, and do some stretching exercises.',
            completed: false,
            startTime: '06:00',
            duration: 30,
            
            priority: 'medium',
            status: 'pending'
        },
        {
            id: 2,
            text: 'Stomach (07:00-09:00) - Have a nutritious breakfast',
            description: 'Eat a nutritious breakfast to start your day.',
            completed: false,
            startTime: '08:00',
            duration: 60,
            
            priority: 'medium',
            status: 'pending'
        },
        {
            id: 3,
            text: 'Spleen (09:00-11:00) - Mental tasks and morning meetings',
            description: 'Engage in mental tasks and attend morning meetings.',
            completed: false,
            startTime: '10:00',
            duration: 120,
            
            priority: 'high',
            status: 'pending'
        },
        {
            id: 4,
            text: 'Heart (11:00-13:00) - High noon, eat a healthy lunch and take a nap',
            description: 'Enjoy a healthy and balanced lunch and have a rest.',
            completed: false,
            startTime: '12:00',
            duration: 60,
            
            priority: 'medium',
            status: 'pending'
        },
        {
            id: 5,
            text: 'Small Intestine (13:00-15:00) - Hydrate with water and fruits',
            description: 'Stay hydrated and carry out focus work.',
            completed: false,
            startTime: '14:00',
            duration: 30,
            
            priority: 'low',
            status: 'pending'
        },
        {
            id: 6,
            text: 'Bladder (15:00-17:00) - Physical exercise or outdoor activities',
            description: 'Engage in physical exercise or outdoor activities.',
            completed: false,
            startTime: '16:00',
            duration: 60,
            
            priority: 'high',
            status: 'pending'
        },
        {
            id: 7,
            text: 'Pericardium (19:00-21:00) - Family time or personal hobbies',
            description: 'Spend quality time with family or engage in personal hobbies.',
            completed: false,
            startTime: '18:00',
            duration: 60,
           
            priority: 'low',
            status: 'pending'
        },
        {
            id: 8,
            text: 'Triple Heater (21:00-23:00) - Wind down, prepare for sleep',
            description: 'Wind down and prepare your body and mind for sleep.',
            completed: false,
            startTime: '22:00',
            duration: 60,
            
            priority: 'medium',
            status: 'pending'
        },
        {
            id: 9,
            text: 'Gallbladder (23:00-01:00) - Deep sleep for rejuvenation',
            description: 'Get a good night\'s sleep for body rejuvenation.',
            completed: false,
            startTime: '00:00',
            duration: 120,
            category: 'personal',
            priority: 'medium',
            status: 'pending'
        },
    ]);
    
    const [selectedCategory, setSelectedCategory] = useState('work');
    const [selectedPriority, setSelectedPriority] = useState('medium');
    
    const categories = ['work', 'personal'];
    const priorities = ['high', 'medium', 'low'];
    const [modalState, setModalState] = useState({
        visible: false,
        title: '',
        description: '',
        startTime: new Date(),
        deadline: null,
        duration: 0,
        category: '',
        priority: '',
        status:'pending',
    });
    const getHoursSpentByCategory = (category) => {
        return tasks.reduce((totalHours, task) => {
            if (task.category === category) {
                return totalHours + task.duration;
            }
            return totalHours;
        }, 0);
    };
    
    const [totalWorkHours, setTotalWorkHours] = useState(getHoursSpentByCategory('work'));
    const [totalPersonalHours, setTotalPersonalHours] = useState(getHoursSpentByCategory('personal'));
    
    
    const [showDeadlinePicker, setShowDeadlinePicker] = useState(false);
    const [showStarttimePicker, setShowStarttimePicker] = useState(false);
    
    useEffect(() => {
        registerForPushNotificationsAsync()
        .then(token => setExpoPushToken(token ?? ''))
        .catch(error => setExpoPushToken(`${error}`));
        
        notificationListener.current = Notifications.addNotificationReceivedListener(setNotification);
        responseListener.current = Notifications.addNotificationResponseReceivedListener(response => console.log(response));
        
        return () => {
            if (notificationListener.current) Notifications.removeNotificationSubscription(notificationListener.current);
            if (responseListener.current) Notifications.removeNotificationSubscription(responseListener.current);
        };
    }, []);
    
    const toggleTaskCompletion = (taskId) => {
        setTasks(prevTasks =>
                 prevTasks.map(task =>
                               task.id === taskId ? { ...task, completed: !task.completed, status: !task.completed ? 'done' : 'pending' } : task
                               )
                 );
        setHealthTasks(prevHealthTasks =>
                prevHealthTasks.map(task =>
                    task.id === taskId ? { ...task, completed: !task.completed } : task
                )
            );
        
    };
    
    const handleAddTask = () => {
        setModalState({ ...modalState, visible: true });
    };
    
    
    const resetModalState = () => {
        setModalState({ visible: false, title: '', description: '', startTime: new Date(), deadline: null, duration: 0 ,category:'', priority:'' });
    };
    const calculateDuration = (startTime, deadline) => {
        if (startTime && deadline) {
            const durationInMinutes = Math.abs(deadline - startTime) / (1000 * 60);
            return durationInMinutes;
        }
        return 0;
    };
    
    const handleStarttimeChange = (event, selectedDate) => {
        const currentDate = selectedDate || modalState.startTime;
        setShowStarttimePicker(true);
        setModalState(prevState => ({ ...prevState, startTime: currentDate }));
        
        const duration = calculateDuration(currentDate, modalState.deadline);
        setModalState(prevState => ({ ...prevState, duration: duration }));
    };
    
    const handleDeadlineChange = (event, selectedDate) => {
        const currentDate = selectedDate || modalState.deadline;
        setShowDeadlinePicker(true);
        setModalState(prevState => ({ ...prevState, deadline: currentDate }));
        
        const duration = calculateDuration(modalState.startTime, currentDate);
        setModalState(prevState => ({ ...prevState, duration: duration }));
    };
    
    
    const scheduleTaskNotification = async (task) => {
        const notificationTime = new Date(task.deadline);
            notificationTime.setHours(notificationTime.getHours() - 1); // Set time to one hour before the deadline
       
            // Schedule the notification
        console.log(notificationTime);
            await Notifications.scheduleNotificationAsync({
                content: {
                    to: expoPushToken,
                    sound:'default',
                    title: `Reminder: ${task.text}`,
                    body: task.description,
                    data: { taskId: task.id },
                    timeZone:'UTC',
                },
                trigger:notificationTime,
            });
        
    };

    
//    const sendNotificationForMatchingTime = async (task) => {
//        const now = new Date();
//        const notificationTime = new Date(now);
//
//        if (task.startTime) {
//            const [taskHour, taskMinute] = task.startTime.split(':').map(Number);
////            console.log(taskHour, taskMinute, task.startTime);
//
//            // Set the notification time to the specified hour and minute
//            notificationTime.setHours(taskHour, taskMinute, 0, 0);
//
//            // Send the notification
////            console.log(`Sending notification for task: ${task.text}`);
////            console.log(notificationTime);
//
//            // Schedule the notification
//            await Notifications.scheduleNotificationAsync({
//                content: {
//                    to: expoPushToken,
//                    sound: 'default',
//                    title: `Reminder: ${task.text}`,
//                    body: task.description,
//                    data: { taskId: task.id },
//                    timezone:'UTC',
//                },
//                trigger:
//                notificationTime,
//            });
//        }
//    };
//
//    // Loop through the healthtasks list and check for matching start times to send notifications
//    healthTasks.forEach(async (task) => {
//        await sendNotificationForMatchingTime(task);
//    });
    
    const handleConfirmTask = () => {
        const newTask = {
            id: tasks.length + 1,
            text: modalState.title,
            description: modalState.description,
            completed: false,
            startTime: modalState.startTime,
            deadline: modalState.deadline,
            duration: modalState.duration,
            category: selectedCategory,
            priority: selectedPriority,
            status: modalState.status,
        };

        scheduleTaskNotification(newTask);
        
                    const speechString = `Task added: ${modalState.title}. Description: ${modalState.description}`;
                        Speech.speak(speechString); // Speak the task details
        // Check if the category is "personal"
        
            setHealthTasks(prevHealthTasks => [...prevHealthTasks, newTask]); // Assuming setHealthTasks is the setter for HealthTasks array
       
            setTasks(prevTasks => [...prevTasks, newTask]);
        

        resetModalState();
    };
    
    // Update total work and personal hours using the updated tasks array
    
    const router = useRouter();
    let tasksDisplay = tasks.map(task => ({
        key:task.id,
        date: task.startTime.toISOString().split('T')[0], // Extracting date from startTime
        time: task.startTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12:false,timeZone: 'UTC'  }), // Formatting time
        //        startTime : task.startTime.toLocaleTimeString().replace(/\.\d+/, ''),
        //        endTime : task.dealine.toLocaleTimeString().replace(/\.\d+/, ''),
        title: task.text, // Using text as title
    }));
    
    useEffect(() => {
        tasksDisplay = tasks.map(task => ({
            key:task.id,
            date: task.startTime.toISOString().split('T')[0], // Extracting date from startTime
            time: task.startTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12:false ,timeZone: 'UTC' }), // Formatting time
            //            startTime : task.startTime.toLocaleTimeString().replace(/\.\d+/, ''),
            //            endTime : task.dealine.toLocaleTimeString().replace(/\.\d+/, ''),
            title: task.text, // Using text as title
        }));
        
        router.push({ pathname: "/calendar", params: {
            _tasks: JSON.stringify(tasksDisplay)
        }});
        
        router.push({ pathname: "/task"});
        
    }, [tasks]);
    
    useEffect(() => {
//        console.log('Total Work Hours:', totalWorkHours);
//        console.log('Total Personal Hours:', totalPersonalHours);
//        console.log(tasks);
//        console.log("hello"+JSON.stringify(tasks));
        setTotalWorkHours(getHoursSpentByCategory('work'));
        setTotalPersonalHours(getHoursSpentByCategory('personal'));
        
        
        
        
        const params = {_tasks: JSON.stringify(tasksDisplay), WorkHours: getHoursSpentByCategory('work'), PersonalHours: getHoursSpentByCategory('personal') }; // Your data to pass
        console.log(params);
        
        // Automatically navigate to the Task screen and pass parameters
        router.push({ pathname: "/", params });
        
        router.push({ pathname: "/task"});
    }, [modalState]);
    
    const handleDelete = (taskId) => {
        setTasks((prevTasks) => prevTasks.filter((task) => task.id !== taskId));
        setHealthTasks((prevTasks) => prevTasks.filter((task) => task.id !== taskId));
    };
    const [isEditing, setIsEditing] = useState(false);
    const handleEdit = (taskId) => {
        const taskToEdit = tasks.find(task => task.id === taskId);
        if (taskToEdit) {
            setModalState({
                visible: true,
                title: taskToEdit.text,
                description: taskToEdit.description,
                startTime: taskToEdit.startTime,
                deadline: taskToEdit.deadline,
                duration: taskToEdit.duration,
                status: taskToEdit.status,
            });
            setSelectedCategory(taskToEdit.category);
            setSelectedPriority(taskToEdit.priority);
            setIsEditing(true); // Set editing mode
        }
        console.log(`Editing task with ID: ${taskId}`);
    };
    const handleConfirmChanges = () => {
        const updatedTask = {
            id: tasks.length + 1, // Ensure the ID remains the same
            text: modalState.title,
            description: modalState.description,
            completed: false, // or retain original completed status
            startTime: modalState.startTime,
            deadline: modalState.deadline,
            duration: modalState.duration,
            category: selectedCategory,
            priority: selectedPriority,
            status: modalState.status,
        };

        // Update the task in the tasks array
        setTasks(prevTasks =>
            prevTasks.map(task => task.id === updatedTask.id ? updatedTask : task)
        );

        resetModalState();
        setIsEditing(false); // Reset editing mode
    };
    // Define the Tasks and HealthTasks components
    const TasksRoute = ({ category }) => (
        <ScrollView style={{ flex: 1 }}>
            {Array.isArray(tasks) && tasks.length > 0 ? (
                tasks
                    .filter(task => task.category === 'work') // Filter tasks by category
                    .map(task => (
                        <View key={task.id} style={styles.taskItem}>
                            <TouchableOpacity onPress={() => toggleTaskCompletion(task.id)} style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <View style={styles.checkbox}>
                                    {task.completed && <View style={styles.checkboxInner} />}
                                </View>
                                <TouchableOpacity onPress={() => toggleTaskCompletion(task.id)} style={{ marginLeft: 8, flex: 1 }}>
                                    <View>
                                        <Text style={{ textDecorationLine: task.completed ? 'line-through' : 'none' }}>
                                            {task.text}
                                        </Text>
                                        {task.deadline && (
                                            <Text style={{ color: '#808080', fontSize: 12 }}>
                                                Deadline: {formatDate(task.deadline)}
                                            </Text>
                                        )}
                                    </View>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => handleEdit(task.id)} style={{ backgroundColor: '#97d9ea', padding: 10, borderRadius: 10 }}>
                                    <Text>Edit</Text>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => handleDelete(task.id)} style={{ backgroundColor: '#e592a3', padding: 10, borderRadius: 10 }}>
                                    <Text>Delete</Text>
                                </TouchableOpacity>
                            </TouchableOpacity>
                        </View>
                    ))
            ) : (
                <Text>No tasks available</Text>
            )}
        </ScrollView>
    );
    
    const PersonalTasksRoute = ({ category }) => (
        <ScrollView style={{ flex: 1 }}>
            {Array.isArray(tasks) && tasks.length > 0 ? (
                tasks
                    .filter(task => task.category === 'personal') // Filter tasks by category
                    .map(task => (
                        <View key={task.id} style={styles.taskItem}>
                            <TouchableOpacity onPress={() => toggleTaskCompletion(task.id)} style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <View style={styles.checkbox}>
                                    {task.completed && <View style={styles.checkboxInner} />}
                                </View>
                                <TouchableOpacity onPress={() => toggleTaskCompletion(task.id)} style={{ marginLeft: 8, flex: 1 }}>
                                    <View>
                                        <Text style={{ textDecorationLine: task.completed ? 'line-through' : 'none' }}>
                                            {task.text}
                                        </Text>
                                        {task.deadline && (
                                            <Text style={{ color: '#808080', fontSize: 12 }}>
                                                Deadline: {formatDate(task.deadline)}
                                            </Text>
                                        )}
                                    </View>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => handleEdit(task.id)} style={{ backgroundColor: '#97d9ea', padding: 10, borderRadius: 10 }}>
                                    <Text>Edit</Text>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => handleDelete(task.id)} style={{ backgroundColor: '#e592a3', padding: 10, borderRadius: 10 }}>
                                    <Text>Delete</Text>
                                </TouchableOpacity>
                            </TouchableOpacity>
                        </View>
                    ))
            ) : (
                <Text>No tasks available</Text>
            )}
        </ScrollView>
    );
    
    const HealthTasksRoute = () => (
                                    <ScrollView style={{ flex: 1 }}>
                                    {Array.isArray(healthTasks) && healthTasks.length > 0 ? (
     healthTasks.map((task) => (
                                <View key={task.id} style={styles.taskItem}>
                                <TouchableOpacity onPress={() => toggleTaskCompletion(task.id)} style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <View style={styles.checkbox}>
                                {task.completed && <View style={styles.checkboxInner} />}
                                </View>
                                <TouchableOpacity onPress={() => toggleTaskCompletion(task.id)} style={{ marginLeft: 8, flex: 1 }}>
                                <View>
                                <Text style={{ textDecorationLine: task.completed ? 'line-through' : 'none' }}>
                                {task.text}
                                </Text>
                                {task.deadline && (
                                                   <Text style={{ color: '#808080', fontSize: 12 }}>
                                                   Deadline: {formatDate(task.deadline)}
                                                   </Text>
                                                   )}
                                </View>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => handleEdit(task.id)} style={{ backgroundColor: '#97d9ea', padding: 10, borderRadius: 10 }}>
                                <Text>Edit</Text>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => handleDelete(task.id)} style={{ backgroundColor: '#e592a3', padding: 10, borderRadius: 10 }}>
                                <Text>Delete</Text>
                                </TouchableOpacity>
                                </TouchableOpacity>
                                </View>
                                ))
     ) : (
          <Text>No tasks available</Text>
                                                                                                  )}
                                    </ScrollView>
                                    );
    const renderScene = SceneMap({
        tasks: () => <TasksRoute category="work" />,       // Display work tasks
        personalTasks: () => <PersoanlTasksRoute category="personal" />, // Display personal tasks
        healthTasks: () => <HealthTasksRoute healthTasks/>,
    });
    const [time, setTime] = useState(new Date());

      useEffect(() => {
        const interval = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(interval);
      }, []);

      const seconds = time.getSeconds();
      const minutes = time.getMinutes();
      const hours = time.getHours();
      const isPM = hours >= 12;

      const secondAngle = (seconds / 60) * 360;
      const minuteAngle = (minutes / 60) * 360 + (seconds / 60) * 6;
      const hourAngle = (hours % 12) * 30 + (minutes / 60) * 30; // Adjust for 12-hour rotation

      const currentActivity = (isPM ? activitiesPM : activitiesAM).find((a) => {
        return time.getHours() % 12 >= a.time && time.getHours() % 12 < a.time + 2;
      });
    // Simple rule-based priority logic
    useEffect(() => {
        console.log(modalState.deadline,modalState.startTime);
        // Step 1: Parse the date strings into Date objects
        const deadlineDate = new Date(modalState.deadline);
        const startTimeDate = new Date(modalState.startTime);

        // Step 2: Calculate the difference in milliseconds
        const differenceInMillis = deadlineDate - startTimeDate; // Result in milliseconds

        // Step 3: Convert milliseconds to days
        const millisecondsInADay = 24 * 60 * 60 * 1000; // Number of milliseconds in a day
        const daysLeft = Math.floor(differenceInMillis / millisecondsInADay); // Floor to get whole days

        // If you need to ensure it's a single-digit number (0-9):
        const DaysLeft = Math.max(0, Math.min(9, daysLeft)); // Clamp value between 0 and 9
        let complexity = 3;
            const score = (7 - daysLeft) * complexity;
            let priority = 'Low';
            
            if (score > 20) {
                priority = 'High';
            } else if (score > 10) {
                priority = 'Medium';
            }
            
            setSelectedPriority(priority);
        
    }, [modalState]);
    

 
    
    return (
            <ParallaxScrollView headerBackgroundColor={{ light: '#A1CEDC', dark: '#1D3D47' }}>
            <ThemedView style={styles.titleContainer}>
            <ThemedText type="title">Tasks</ThemedText>
            </ThemedView>
            <View style={styles.container}>
                  <Svg height="250" width="250" viewBox="0 0 200 200">
                    {/* Clock Face */}
                    <Circle cx="100" cy="100" r="90" stroke="#97d9ea" strokeWidth="5" fill="white" />

                    {/* Hour Markers */}
                    {[...Array(12)].map((_, i) => {
                      const angle = (i * 30) * (Math.PI / 180);
                      return (
                        <SvgText
                          key={i}
                          x={100 + 75 * Math.sin(angle)}
                          y={100 - 75 * Math.cos(angle) + 4}
                          fontSize="14"
                          fontWeight="bold"
                          textAnchor="middle"
                          fill="#333"
                        >
                          {i === 0 ? 12 : i}
                        </SvgText>
                      );
                    })}

                    {/* Activity Icons */}
                    {(isPM ? activitiesPM : activitiesAM).map((activity, index) => {
                      const angle = (activity.time % 12) * 30 * (Math.PI / 180);
                      return (
                        <FontAwesome5
                          key={index}
                          name={activity.icon}
                          size={18} // Increased size for visibility
                          color={activity.color}
                          style={{
                            position: "absolute",
                            left: 125 + 75 * Math.sin(angle) - 9,
                            top: 125 - 75 * Math.cos(angle) - 9,
                          }}
                        />
                      );
                    })}

                    {/* Hour Hand */}
                    <Line
                      x1="100"
                      y1="100"
                      x2="100"
                      y2="60"
                      stroke="#333"
                      strokeWidth="6"
                      strokeLinecap="round"
                      transform={`rotate(${hourAngle} 100 100)`}
                    />

                    {/* Minute Hand */}
                    <Line
                      x1="100"
                      y1="100"
                      x2="100"
                      y2="40"
                      stroke="#555"
                      strokeWidth="4"
                      strokeLinecap="round"
                      transform={`rotate(${minuteAngle} 100 100)`}
                    />

                    {/* Second Hand */}
                    <Line
                      x1="100"
                      y1="100"
                      x2="100"
                      y2="30"
                      stroke="red"
                      strokeWidth="2"
                      strokeLinecap="round"
                      transform={`rotate(${secondAngle} 100 100)`}
                    />

                    {/* Center Circle */}
                    <Circle cx="100" cy="100" r="4" fill="#333" />

                    {/* AM/PM Indicator */}
                    <SvgText
                      x="100"
                      y="90"
                      fontSize="18"
                      fill={isPM ? "#3F51B5" : "#FF9800"}
                      textAnchor="middle"
                      fontWeight="bold"
                    >
                      {isPM ? "🌙PM" : "☀️AM"}
                    </SvgText>
                  </Svg>

                  {/* Display Current Activity */}
                  <View style={[styles.activityContainer, { backgroundColor: currentActivity?.color || "#ddd" }]}>
                    <Text style={styles.activityText}>
                      {currentActivity?.label || "Relax"}
                    </Text>
                  </View>
                </View>
            <Text>Tab the task to mark it when you finish, it would disable that task notificaiton reminder</Text>
            <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-around', padding: 10 }}>
            {routes.map((route, i) => (
                                       <TouchableOpacity key={route.key} onPress={() => setIndex(i)}>
                                       <Text style={{ fontWeight: index === i ? 'bold' : 'normal' }}>{route.title}</Text>
                                       </TouchableOpacity>
                                       ))}
            </View>
            {index === 0 ? (
                <TasksRoute />
            ) : index === 1 ? (
                <PersonalTasksRoute />
            ) : (
                <HealthTasksRoute />
            )}
            </View>
            <TouchableOpacity onPress={handleAddTask} style={styles.addTaskButton}>
            <IconSymbol size={24} name="plus" color="#808080" />
            <ThemedText>Add Task</ThemedText>
            </TouchableOpacity>
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            
            <Modal
                  transparent
                  visible={modalState.visible}
                  animationType="slide"
                  onRequestClose={() => setModalState(prev => ({ ...prev, visible: false }))}
                >
                  {/* Outside Tap Closes Modal */}
                  <TouchableWithoutFeedback onPress={() => setModalState(prev => ({ ...prev, visible: false }))}>
                    <View style={styles.modalOverlay}>
                      {/* Prevent Closing When Clicking Inside Modal */}
                      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
                        <View style={styles.modalContainer}>
                          <ScrollView contentContainerStyle={styles.scrollContainer}>
                            <Text style={styles.header}>Add New Task</Text>

                            <Text style={styles.label}>Task Title:</Text>
                            <TextInput
                              value={modalState.title}
                              onChangeText={(text) => setModalState(prev => ({ ...prev, title: text }))}
                              style={styles.input}
                              placeholder="e.g. Finish Project Presentation"
                            />

                            <Text style={styles.label}>Task Description:</Text>
                            <TextInput
                              value={modalState.description}
                              onChangeText={(text) => setModalState(prev => ({ ...prev, description: text }))}
                              style={[styles.input, { height: 100 }]}
                              multiline
                              placeholder="e.g. Include key findings and recommendations"
                            />

                            <Text style={styles.label}>Select Category:</Text>
                            <ScrollView horizontal>
                              {categories.map((category, index) => (
                                <TouchableOpacity
                                  key={index}
                                  style={[
                                    styles.categoryButton,
                                    selectedCategory === category && styles.selectedCategory
                                  ]}
                                  onPress={() => setSelectedCategory(category)}
                                >
                                  <Text style={styles.categoryText}>{category}</Text>
                                </TouchableOpacity>
                              ))}
                            </ScrollView>

          
                            <Text style={styles.label}>Select Start Time:</Text>
                            <TouchableOpacity onPress={() => setShowStarttimePicker(true)} style={styles.dateButton}>
                              <IconSymbol name="calendar" size={24} color="#808080" />
                              <Text style={styles.dateText}>
                                {modalState.startTime ? modalState.startTime.toLocaleString() : 'Select Start Time'}
                              </Text>
                            </TouchableOpacity>
                            {showStarttimePicker && (
                              <DatePickerComponent
                                value={modalState.startTime || new Date()}
                                mode="datetime"
                                is24Hour={true}
                                display="default"
                                onChange={handleStarttimeChange}
                              />
                            )}

                            <Text style={styles.label}>Select Deadline:</Text>
                            <TouchableOpacity onPress={() => setShowDeadlinePicker(true)} style={styles.dateButton}>
                              <IconSymbol name="calendar" size={24} color="#808080" />
                              <Text style={styles.dateText}>
                                {modalState.deadline ? modalState.deadline.toLocaleString() : 'Select Deadline'}
                              </Text>
                            </TouchableOpacity>
                            {showDeadlinePicker && (
                              <DatePickerComponent
                                value={modalState.deadline || new Date()}
                                mode="datetime"
                                is24Hour={true}
                                display="default"
                                onChange={handleDeadlineChange}
                              />
                            )}

                            <Text style={styles.durationText}>Duration: {modalState.duration} Minutes</Text>
            <View>
                 <Text style={styles.label}>Select Priority:</Text>
            <Text style={styles.infoText}>
              Smart Suggestion: <Text style={{ fontWeight: 'bold' }}>{selectedPriority}</Text>
            </Text>
                 <ScrollView horizontal>
            
                   {priorities.map((priority, index) => (
                     <TouchableOpacity
                       key={index}
                       style={[
                         styles.priorityButton,
                         selectedPriority === priority && styles.selectedPriority
                       ]}
                       onPress={() => setSelectedPriority(priority)}
                     >
                       <Text style={styles.priorityText}>{priority}</Text>
                     </TouchableOpacity>
                   ))}
                 </ScrollView>
                 
               </View>
                            <Text style={styles.reminderText}>
                              A reminder notification will be sent one hour before the deadline.
                            </Text>

            <Button
                title={isEditing ? "Confirm Changes" : "Confirm Task"}
                onPress={isEditing ? handleConfirmChanges : handleConfirmTask}
                color="#007BFF"
            />
                          </ScrollView>
                        </View>
                      </TouchableWithoutFeedback>
                    </View>
                  </TouchableWithoutFeedback>
                </Modal>
         
                </View>
            </ParallaxScrollView>
            );
}

const styles = StyleSheet.create({
    headerImage: {
        color: '#808080',
        bottom: -90,
        left: -35,
        position: 'absolute',
    },
    titleContainer: {
        flexDirection: 'row',
        gap: 8,
    },modalContainer: {
        flex: 1,
        padding:10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    input: {
        width: '100%',
        height: 45,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 8,
        paddingHorizontal: 10,
        fontSize: 14,
        backgroundColor: '#f9f9f9',
    },
    PickerContainer:{
        flex:1,
    },
    picker: {
        flex:1,
        width: 200,
        borderColor: 'gray',
        borderWidth:0,
    },
    itemStyle: {
        fontSize: 16,
        margin:10,
    },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#CCCCCC',
        borderRadius: 5,
        padding: 8,
        marginBottom: 16,
    },label: {
        alignSelf: 'flex-start',
        fontSize: 14,
        fontWeight: '600',
        color: '#555',
        marginTop: 10,
    },
    inputText: {
        marginLeft: 8,
        color: 'black',
    },
    reminderText: {
        marginTop: 16,
        color: '#808080',
    },
    button: {
        backgroundColor: '#007AFF',
        color: '#FFFFFF',
        padding: 12,
        borderRadius: 5,
        textAlign: 'center',
    },
    container: {
        flexDirection: 'row',
    },
    image2: {
        width: 200,
        height: 200,
        marginHorizontal: 10,
        borderRadius:10,
    },
    taskItem: {
        backgroundColor: '#f9f9f9',
        borderRadius: 10,
        marginVertical: 8,
        padding: 12,
        elevation: 2, // For Android shadow
        shadowColor: '#000', // iOS shadow
        shadowOpacity: 0.1,
        shadowOffset: { width: 0, height: 1 },
        shadowRadius: 3,
    }, tabBar: {
        backgroundColor: '#A1CEDC',
        borderRadius:50,
    },
    indicator: {
        backgroundColor: '#1D3D47',
    },
    tabLabel: {
        color: '#fff',
    },
    taskRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    button: {
        marginLeft: 10,
        backgroundColor: '#97d9ea',
        padding: 5,
        borderRadius: 5,
    },
    checkbox: {
        width: 20,
        height: 20,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 5,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 10,
    },
    checkboxInner: {
        width: 10,
        height: 10,
        backgroundColor: '#1D3D47',
        borderRadius: 5,
    },
    editButton: {
        backgroundColor: '#97d9ea',
        padding: 10,
        borderRadius: 10,
        marginLeft: 10,
    },
    deleteButton: {
        backgroundColor: '#e592a3',
        padding: 10,
        borderRadius: 10,
        marginLeft: 10,
    },
    container: {
       flex: 1,
       alignItems: "center",
       justifyContent: "center",
     },
     activityContainer: {
       marginTop: 20,
       padding: 10,
       borderRadius: 10,
       elevation: 2,
     },
     activityText: {
       fontSize: 18,
       fontWeight: "bold",
       color: "#fff",
     },
    modalOverlay: {
        flex: 1,
        justifyContent: 'flex-end',
        backgroundColor: 'rgba(0, 0, 0, 0.5)', // Semi-transparent background
      },
      modalContainer: {
        backgroundColor: 'white',
        padding: 20,
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        height: '50%', // Only covers bottom half
        width: '100%',
      },
    scrollContainer: {
        paddingBottom: 20,
      },
      header: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        textAlign: 'center',
      },
      label: {
        fontWeight: 'bold',
        marginVertical: 10,
      },
      input: {
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 5,
        padding: 10,
        marginBottom: 15,
      },
      categoryButton: {
        padding: 10,
        margin: 5,
        backgroundColor: '#e0e0e0',
        borderRadius: 5,
      },
      selectedCategory: {
        backgroundColor: '#a1cedc',
      },
      priorityButton: {
        padding: 10,
        margin: 5,
        backgroundColor: '#e0e0e0',
        borderRadius: 5,
      },

      selectedPriority: {
        backgroundColor: '#a1cedc',
      },
      dateButton: {
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 5,
        padding: 10,
        marginBottom: 15,
        backgroundColor: '#f8f8f8',
      },
      dateText: {
        marginLeft: 10,
        color: '#333',
      },
      durationText: {
        marginVertical: 10,
        fontWeight: 'bold',
      },
      reminderText: {
        marginTop: 10,
        color: '#666',
        textAlign: 'center',
      },
});
