import {
  StyleSheet,
  Platform,
  Alert,
  TouchableOpacity,
  Switch,
} from 'react-native';
import React, { useState, useEffect } from 'react';
import * as Calendar from 'expo-calendar';
import { Collapsible } from '@/components/Collapsible';
import { ExternalLink } from '@/components/ExternalLink';
import ParallaxScrollView from '@/components/ParallaxScrollView';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { IconSymbol } from '@/components/ui/IconSymbol';
import {
  Calendar as RNCalendar,
  CalendarList,
  Agenda,
  LocaleConfig,
} from 'react-native-calendars';
import { useLocalSearchParams } from 'expo-router';
import Timetable from 'react-native-calendar-timetable';

export default function TabTwoScreen() {
  const { _tasks } = useLocalSearchParams();
  let tasks = [];

  try {
    if (_tasks) {
      tasks = JSON.parse(_tasks);
      console.log(tasks);
    }
  } catch (error) {
    console.error('Error parsing JSON: ', error);
  }

  const [selectedDate, setSelectedDate] = useState(null);
  const [calendarId, setCalendarId] = useState(null);
  const [localEvents, setLocalEvents] = useState([]);

  useEffect(() => {
    (async () => {
      const { status } = await Calendar.requestCalendarPermissionsAsync();
      if (status === 'granted') {
        const calendars = await Calendar.getCalendarsAsync(
          Calendar.EntityTypes.EVENT
        );
        console.log('Available Calendars:', calendars);

        if (calendars.length > 0) {
          setCalendarId(calendars[0].id); // Use the first available calendar

          const events = await Calendar.getEventsAsync(
            [calendarId],
            new Date(),
            new Date().getTime() + 7 * 24 * 60 * 60 * 1000
          );
          console.log('Local Events:', events);
          setLocalEvents(events);
        } else {
          Alert.alert('No calendar found', 'Please create a calendar first.');
        }
      } else {
        Alert.alert('Permission Denied', 'You need to grant calendar access.');
      }
    })();
  }, [calendarId]); // Fetch events when calendarId changes

  const addEventToCalendar = async (task) => {
    if (!calendarId) {
      Alert.alert('No Calendar Found', 'Cannot add event.');
      return;
    }

    try {
      const startDate = new Date(`${task.date}T${task.time}:00Z`);
      const endDate = new Date(`${task.date}T${task.time}:30Z`);

      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        Alert.alert('Invalid Date', 'Please provide a valid date and time.');
        return;
      }

      await Calendar.createEventAsync(calendarId, {
        title: task.title,
        startDate,
        endDate,
        timeZone: 'UTC',
        location: task.location || '',
      });
      Alert.alert('Event Added', `Task "${task.title}" added to calendar.`);
    } catch (error) {
      console.error('Error adding event:', error);
      Alert.alert('Error', 'Could not add event.');
    }
  };

  const renderLocalEvents = () => {
    return localEvents.map((event) => (
      <ThemedView key={event.id} style={styles.eventItem}>
        <ThemedText>{event.title}</ThemedText>
        <ThemedText>{event.startDate.toString()}</ThemedText>
      </ThemedView>
    ));
  };

  const renderTaskList = () => {
    if (!selectedDate) {
      return null;
    }

    const tasksForSelectedDate = tasks.filter(
      (task) => task.date === selectedDate
    );
    tasksForSelectedDate.sort((a, b) => a.time.localeCompare(b.time));

    return tasksForSelectedDate.map((task) => (
      <ThemedView key={task.key} style={styles.taskItem}>
        <ThemedText>{task.time}</ThemedText>
        <ThemedText>{task.title}</ThemedText>
        <ThemedText
          onPress={() => addEventToCalendar(task)}
          style={styles.addToCalendar}>
          ➕ Add to Calendar
        </ThemedText>
      </ThemedView>
    ));
  };

  return (
    <ParallaxScrollView
      headerBackgroundColor={{ light: '#D0D0D0', dark: '#353636' }}
      headerImage>
      <ThemedView style={styles.titleContainer}>
        <ThemedText type="title">Calendar</ThemedText>
      </ThemedView>
      <ThemedView title="Calendar">
        <RNCalendar
          onDayPress={(day) => setSelectedDate(day.dateString)}
          markedDates={{
            [selectedDate]: {
              selected: true,
              selectedColor: '#64c7dc',
              disableTouchEvent: true,
              marked: true,
              selectedDotColor: 'orange',
            },
          }}
        />
      </ThemedView>
      <ThemedView style={styles.taskListContainer}>
        {renderTaskList()}
      </ThemedView>
      <ThemedView style={styles.eventListContainer}>
        <ThemedText type="subTitle">Local Calendar Events:</ThemedText>
        {renderLocalEvents()}
      </ThemedView>
    </ParallaxScrollView>
  );
}

const styles = StyleSheet.create({
  titleContainer: {
    flexDirection: 'row',
    gap: 8,
    marginVertical: 10,
    padding: 10,
    //    backgroundColor: '#F5F5F5', // Light grey background
    borderRadius: 8,
    elevation: 1, // Add slight shadow for modern feel
  },
  taskListContainer: {
    marginTop: 10,
    paddingHorizontal: 16,
  },
  eventListContainer: {
    marginTop: 20,
    paddingHorizontal: 16,
  },
  taskItem: {
    padding: 15,
    marginVertical: 5,
    backgroundColor: '#E0F7FA', // Light cyan background
    borderRadius: 10,
    elevation: 2, // Adds a shadow effect for depth
  },
  addToCalendar: {
    color: '#007AFF',
    marginTop: 5,
    fontWeight: 'bold',
  },
  eventItem: {
    padding: 15,
    marginVertical: 5,
    backgroundColor: '#FFF', // White background for event items
    borderRadius: 10,
    elevation: 1, // Subtle shadow for event items
  },
});
