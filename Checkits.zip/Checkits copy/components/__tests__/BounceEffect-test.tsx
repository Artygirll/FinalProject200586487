import * as React from 'react';
import renderer from 'react-test-renderer';

import { HelloWave } from '../BounceEffect';

it(`renders correctly`, () => {
  const tree = renderer.create(<HelloWave></HelloWave>).toJSON();

  expect(tree).toMatchSnapshot();
});
