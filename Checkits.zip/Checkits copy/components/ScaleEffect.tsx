import React, { useEffect } from 'react';
import { StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withRepeat,
  withSequence,
  withSpring,
} from 'react-native-reanimated';

import { ThemedText } from '@/components/ThemedText';

export function Achieved() {
    const scaleAnimation = useSharedValue(1);

      useEffect(() => {
        scaleAnimation.value = withRepeat(
          withSequence(
            withTiming(1.2, { duration: 300 }), // Scale up effect
            withTiming(1, { duration: 300 }) // Scale down to original size
          ),
          4 // Run the animation 4 times
        );
      }, []);

      const animatedStyle = useAnimatedStyle(() => ({
        transform: [{ scale: scaleAnimation.value }],
      }));

      return (
        <Animated.View style={animatedStyle}>
          <ThemedText style={styles.text}>🏆</ThemedText>
        </Animated.View>
      );
}
export function Warning() {
  const scaleAnimation = useSharedValue(1);

  useEffect(() => {
    scaleAnimation.value = withRepeat(
      withSequence(
        withTiming(1.2, { duration: 300 }), // Scale up effect
        withTiming(1, { duration: 300 }) // Scale down to original size
      ),
      4 // Run the animation 4 times
    );
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scaleAnimation.value }],
  }));

  return (
    <Animated.View style={animatedStyle}>
      <ThemedText style={styles.text}>⚠️</ThemedText>
    </Animated.View>
  );
}


const styles = StyleSheet.create({
  text: {
    fontSize: 28,
    lineHeight: 32,
    marginBottom: -10,
  },
});
